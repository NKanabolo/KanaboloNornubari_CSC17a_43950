var searchData=
[
  ['war',['war',['../main_8cpp.html#a0a8867b1e11289d970883db934999bd5',1,'main.cpp']]]
];
