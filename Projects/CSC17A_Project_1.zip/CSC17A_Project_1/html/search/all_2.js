var searchData=
[
  ['enemybd',['enemyBd',['../struct_players.html#a6121609150ccdce226350cc99ae2f5e6',1,'Players']]]
];
