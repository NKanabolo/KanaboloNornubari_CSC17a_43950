var searchData=
[
  ['begin',['begin',['../main_8cpp.html#ab0bdf5cca484fb2ba637c39384b27fb2',1,'main.cpp']]],
  ['board',['Board',['../struct_board.html',1,'']]],
  ['board_2eh',['Board.h',['../_board_8h.html',1,'']]]
];
