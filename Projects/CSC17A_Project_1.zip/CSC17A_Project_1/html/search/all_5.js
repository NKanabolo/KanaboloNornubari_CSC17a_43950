var searchData=
[
  ['rows',['rows',['../struct_board.html#ab0678710e0cb026be902dbb6a8ad8c40',1,'Board']]]
];
