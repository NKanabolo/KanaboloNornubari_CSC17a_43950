var searchData=
[
  ['columns',['columns',['../struct_board.html#abd6db5048c565a2236812ae739f12638',1,'Board']]]
];
