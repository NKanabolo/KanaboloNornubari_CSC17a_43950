var searchData=
[
  ['playrbd',['playrBd',['../struct_players.html#abb5b042a3f596d8dcc59ee789e39ab5e',1,'Players']]]
];
