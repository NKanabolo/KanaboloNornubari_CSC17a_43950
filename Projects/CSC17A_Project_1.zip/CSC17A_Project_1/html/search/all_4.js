var searchData=
[
  ['players',['Players',['../struct_players.html',1,'']]],
  ['players_2eh',['Players.h',['../_players_8h.html',1,'']]],
  ['playrbd',['playrBd',['../struct_players.html#abb5b042a3f596d8dcc59ee789e39ab5e',1,'Players']]],
  ['prntbrd',['prntBrd',['../main_8cpp.html#acb722b7038e1a09a439b65544ce4550b',1,'main.cpp']]]
];
