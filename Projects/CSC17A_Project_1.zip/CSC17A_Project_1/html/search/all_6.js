var searchData=
[
  ['ships',['ships',['../struct_board.html#a8516818f13e7662c7cbda336307cf38e',1,'Board']]]
];
