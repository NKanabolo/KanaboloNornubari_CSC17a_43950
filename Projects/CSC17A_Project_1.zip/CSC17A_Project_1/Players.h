/* 
 * File:   Players.h
 * Author: Nornubari's Laptop
 *
 * Created on April 26, 2015, 4:41 PM
 */

#ifndef PLAYERS_H
#define	PLAYERS_H
#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <ctime>

struct Players
{
    char playrBd;  //Array with all the player tokens
    char enemyBd;   //Array with all the enemy tokens
};

#endif	/* PLAYERS_H */

